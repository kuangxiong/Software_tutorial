#include <stdio.h>
#include <omp.h>
#define N 6

int main(int argc, char *argv[])
{
  int i, a[N], b[N], c;
 
#pragma omp parallel
  {
/**
 * 用private说明的变量，其在并行块外的值不能传入并行块，
 * 在并行块内计算出的值也不能传出并行块。为解决这个问题，
 * 可使用firstprivate，和lastprivate。
 */
#pragma omp single
    for (i = 0; i < N; i++)
      {
       a[i] = 10;
      }
b[N-1]=100;
//#pragma omp for private(i,a,b)
#pragma omp for firstprivate(i,a,b) lastprivate(b)
    for (i = 1; i < N; i++)
      {
        b[i] = a[i - 1] + i;
        fprintf(stderr, "Thread# %d, i: %d, a: %d, b: %d\n", 
                omp_get_thread_num(), i, a[i], b[i]);
      }

    c = b[N - 1];
    fprintf(stderr, "Thread# %d, c: %d\n", omp_get_thread_num(), c);
  }
  return (0);
}
