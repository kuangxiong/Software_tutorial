#include <stdio.h>
#include <omp.h>
int main()
{
  int x;
  x = 7;
#pragma omp parallel num_threads(3) shared(x)
//#pragma omp parallel private(x)
  {
    // 定义私有变量y。
    int y;
    y = 3;
    if (omp_get_thread_num() == 0)
      {
        x = 5;
        y = 6;
      }
    else
      {
        x = omp_get_thread_num();
      }
    fprintf(stderr, "Thread# %d: x = %d, y = %d\n", omp_get_thread_num(), x, y);
  }
}
