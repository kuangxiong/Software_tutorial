#include <stdio.h>
#include <omp.h>
#define N 1000000

int main()
{
  int k, sum;
  sum = 0;
#pragma omp parallel for num_threads(10) reduction(+:sum)
  for (k = 0; k < N; k++)
    {
      sum = sum + k;
    }
  fprintf(stderr, "Thread# %d: sum = %d\n", omp_get_thread_num(), sum);
}
