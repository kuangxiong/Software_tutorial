#include <stdio.h>
#include <omp.h>
#define N 10

#if 0
int main(int argc, char *argv[])
{
  int i, a[N], b[N];
#pragma omp parallel for num_threads(3) nowait
  for (i = 0; i < N; i++)
    {
      a[i] = i;
    }

#pragma omp parallel for num_threads(3)
  for (i = 0; i < N; i++)
    {
      b[i] = i + 10;
    }

  return (0);
}

#else

int main(int argc, char *argv[])
{
  int i, a[N], b[N];
#pragma omp parallel num_threads(3)
  { 
    #pragma omp for
    for (i = 0; i < N; i++)
      {
        a[i] = i;
      }

    #pragma omp for
    for (i = 0; i < N; i++)
      {
        b[i] = i + 10;
      }
    fprintf(stderr, "Thread# %d\n", omp_get_thread_num());
  }
  return (0);
}

#endif
